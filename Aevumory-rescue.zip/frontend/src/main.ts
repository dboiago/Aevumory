import './styles.css';
import { renderAmbientDisplay } from './ambient-display';
import { HORIZON_HOURS, DEPARTURE_GRACE_MINUTES, horizonPosition, horizonVisual, selectHorizonCandidates, type HorizonEvent } from './horizon';
import { isHorizonEligible } from './horizon-eligibility';
import { ApiTaskBoardQuery, type HouseholdParticipant } from './tasks';
import { FixtureTaskBoardStore } from './task-board';
import { ApiTemporalQuery, type TemporalOccurrence } from './temporal';
import { ApiCalendarQuery } from './calendar';
import { renderCalendar } from './calendar-view';
import { renderHouseholdSetup } from './household-setup';
import { ApiRewardsQuery } from './rewards';
import { renderRewards } from './rewards-view';
import { renderParticipantProfile } from './participant-profile';
import { renderProfiles } from './profiles';
import { attachPolling, participantsApi, startPolling, stopPolling } from './api-client';
import { installIdleReturn, installSwipeNavigation, noteRoute, syncAppNavigation } from './navigation';
import { renderSettings } from './settings';
import { renderActivity } from './activity';
import { renderCountdown } from './countdown';
import { applyStoredTheme } from './themes';
import { emptyTaskFormState, renderTaskForm, taskFormStateFromTask, type TaskFormState } from './task-form';
import { openPruneDialog } from './prune-dialog';
import type { TaskDto } from './api-client';

type AmbientContext =
  | { kind: 'ordinary'; date: string; time: string; weather: string }
  | { kind: 'transient'; message: string };

type TaskListScrollPositions = Record<string, number>;

type TaskBoardScrollState = {
  board: number;
  lists: TaskListScrollPositions;
};

const root = document.querySelector<HTMLDivElement>('#app');
if (!root) throw new Error('Aevumory application root was not found');

let context: AmbientContext = {
  kind: 'ordinary',
  date: 'Wednesday, September 2',
  time: '18:00',
  weather: 'Clear · 18°',
};

const temporalQuery = new ApiTemporalQuery();
const taskBoardQuery = new ApiTaskBoardQuery();
const calendarQuery = new ApiCalendarQuery();
const rewardsQuery = new ApiRewardsQuery();

applyStoredTheme();
installSwipeNavigation();
installIdleReturn();

void render(root);
window.addEventListener('hashchange', () => void render(root));

async function render(target: HTMLDivElement): Promise<void> {
  noteRoute(window.location.hash);
  await renderRoute(target);
  // The flyout shell lives on <body> (see navigation.ts), so route
  // renders and polling re-renders inside #app cannot remove it; it
  // only needs its visibility/active item synced to the new route.
  syncAppNavigation();
}

async function renderRoute(target: HTMLDivElement): Promise<void> {
  const hash = window.location.hash;

  // Every route starts from a clean slate; only the routes that opt back in
  // below (Task Board, Calendar, Rewards, Participant Profile, Event
  // Horizon) re-attach a poller (FUNCTIONAL_FOUNDATION_PLAN.md Phase 7).
  stopPolling(target);

  if (hash === '#household-setup') {
    await renderHouseholdSetup(target);
    return;
  }

  if (hash === '#settings') {
    renderSettings(target);
    return;
  }

  if (hash === '#activity') {
    await renderActivity(target);
    return;
  }

  if (hash === '#countdown') {
    renderCountdown(target);
    return;
  }

  if (hash === '#calendar') {
    await renderCalendar(target, calendarQuery);
    return;
  }

  if (hash === '#profiles') {
    await renderProfiles(target);
    return;
  }

  if (hash === '#rewards') {
    await renderRewards(target, rewardsQuery);
    return;
  }

  if (hash === '#tasks') {
    const state = await taskBoardQuery.getBoard();
    const store = new FixtureTaskBoardStore(state, () => taskBoardQuery.getBoard());
    renderTaskBoard(target, store);
    attachPolling(target, startPolling(async () => {
      if (taskFormSession) return; // never wipe an open create/edit form
      const scrollState = captureTaskBoardScrollState(target);
      await store.refresh();
      renderTaskBoard(target, store, scrollState);
    }));
    return;
  }

  if (hash === '#ambient-display' || hash.startsWith('#ambient-display/')) {
    renderAmbientDisplay(target, hash);
    return;
  }

  const participantMatch = hash.match(/^#participant\/(.+)$/);
  if (participantMatch) {
    const state = await taskBoardQuery.getBoard();
    const participant = state.participants.find((item) => item.id === decodeURIComponent(participantMatch[1]));
    if (participant) {
      await renderParticipantProfile(target, participant);
      return;
    }
  }

  // The setup flow handles the uninitialized/empty state explicitly: a fresh
  // household with no participants has nothing meaningful to show ambiently yet.
  if (hash === '') {
    const participants = await participantsApi.list().catch(() => null);
    if (participants && participants.length === 0) {
      window.location.hash = '#household-setup';
      return;
    }
  }

  // Event Horizon uses the real current time (Phase 6), unlike the fixture
  // date/time still used for the ambient signature elsewhere on this page —
  // real persisted occurrences need a real temporal reference.
  await renderHorizon(target);
  attachPolling(target, startPolling(() => renderHorizon(target)));
}

async function renderHorizon(target: HTMLDivElement): Promise<void> {
  const horizonNow = new Date().toISOString();
  const windowStart = new Date(Date.now() - DEPARTURE_GRACE_MINUTES * 60_000).toISOString();
  const windowEnd = new Date(Date.now() + HORIZON_HOURS * 3_600_000).toISOString();
  const occurrences = await temporalQuery.listOccurrencesInWindow({
    starts_at: windowStart,
    ends_at: windowEnd,
  });

  target.innerHTML = `
    <main class="horizon" aria-label="Aevumory Event Horizon">
      <div class="horizon-field" aria-label="Upcoming household events">
        ${renderOccurrences(occurrences, horizonNow)}
      </div>
      ${renderAmbientContext(context)}
    </main>
  `;
}

/** Open create/edit form session for the Task Board (module-level so the
 *  polling re-render can preserve/skip it — see the #tasks route). */
let taskFormSession: { state: TaskFormState; editing?: TaskDto } | null = null;

function renderTaskBoard(
  target: HTMLDivElement,
  store: FixtureTaskBoardStore,
  scrollState: TaskBoardScrollState = { board: 0, lists: {} },
): void {
  const state = store.getState();
  const todaysTasks = state.tasks.filter(isTaskForToday);
  const participantSections = state.participants
    .map((participant) => renderParticipantColumn(participant, todaysTasks))
    .join('');
  const householdTasks = todaysTasks.filter((task) => task.assignment === 'household');

  target.innerHTML = `
    <main class="task-board" aria-label="Aevumory Task Board">
      <header class="task-board-header">
        <div>
          <p class="eyebrow">Household</p>
          <h1>Tasks</h1>
        </div>
        <button type="button" class="task-board-add" data-task-add>Add task</button>
      </header>
      <div data-task-form-slot></div>
      <section class="task-columns" aria-label="Household responsibilities">
        ${participantSections}
        ${renderTaskColumn('Household', undefined, householdTasks)}
      </section>
    </main>
  `;

  const board = target.querySelector<HTMLElement>('.task-board');
  if (board) board.scrollTop = scrollState.board;
  restoreTaskListScrollPositions(target, scrollState.lists);

  const closeTaskForm = async (): Promise<void> => {
    taskFormSession = null;
    await store.refresh();
    renderTaskBoard(target, store, captureTaskBoardScrollState(target));
  };
  const formSlot = target.querySelector<HTMLElement>('[data-task-form-slot]');
  if (formSlot && taskFormSession) {
    renderTaskForm(formSlot, taskFormSession.state, state.participants, taskFormSession.editing, {
      onSaved: () => void closeTaskForm(),
      onCancel: () => { taskFormSession = null; renderTaskBoard(target, store, captureTaskBoardScrollState(target)); },
    });
  }
  target.querySelector('[data-task-add]')?.addEventListener('click', () => {
    taskFormSession = { state: emptyTaskFormState() };
    renderTaskBoard(target, store, captureTaskBoardScrollState(target));
  });
  target.querySelectorAll<HTMLButtonElement>('[data-action="edit"]').forEach((button) => {
    button.addEventListener('click', () => {
      const item = state.tasks.find((entry) => entry.taskId === button.dataset.taskDef);
      if (!item) return;
      taskFormSession = { state: taskFormStateFromTask(item.task), editing: item.task };
      renderTaskBoard(target, store, captureTaskBoardScrollState(target));
    });
  });

  target.querySelectorAll<HTMLElement>('[data-task-id]').forEach((card) => {
    card.addEventListener('dragstart', (event) => {
      const dataTransfer = event.dataTransfer;
      if (!dataTransfer) return;
      dataTransfer.effectAllowed = 'move';
      dataTransfer.setData('text/task-id', card.dataset.taskId ?? '');
      card.classList.add('task-card-dragging');
    });

    card.addEventListener('dragend', () => {
      card.classList.remove('task-card-dragging');
      target.querySelectorAll('.task-column-drag-over').forEach((column) => column.classList.remove('task-column-drag-over'));
    });

    if (window.matchMedia('(pointer: coarse)').matches) {
      card.draggable = false;
      setupTouchDrag(target, store, card);
    }
  });

  target.querySelectorAll<HTMLElement>('[data-drop-target]').forEach((column) => {
    column.addEventListener('dragover', (event) => {
      event.preventDefault();
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'move';
      column.classList.add('task-column-drag-over');
    });

    column.addEventListener('dragleave', (event) => {
      if (!column.contains(event.relatedTarget as Node | null)) {
        column.classList.remove('task-column-drag-over');
      }
    });

    column.addEventListener('drop', (event) => {
      event.preventDefault();
      column.classList.remove('task-column-drag-over');
      const taskId = event.dataTransfer?.getData('text/task-id');
      if (!taskId) return;

      applyTaskAssignment(target, store, taskId, column.dataset.dropTarget || undefined);
    });
  });

  target.querySelectorAll<HTMLButtonElement>('[data-participant-id]').forEach((button) => {
    button.addEventListener('click', () => {
      const participantId = button.dataset.participantId;
      if (participantId) window.location.hash = `#participant/${encodeURIComponent(participantId)}`;
    });
  });

  target.querySelectorAll<HTMLButtonElement>('[data-action="complete"]').forEach((button) => {
    button.addEventListener('click', async () => {
      const scrollState = captureTaskBoardScrollState(target);
      await store.apply({ kind: 'complete', taskId: button.dataset.taskId ?? '' });
      renderTaskBoard(target, store, scrollState);
    });
  });

  target.querySelectorAll<HTMLButtonElement>('[data-action="foothold"]').forEach((button) => {
    button.addEventListener('click', async () => {
      const scrollState = captureTaskBoardScrollState(target);
      await store.apply({ kind: 'foothold', taskId: button.dataset.taskId ?? '' });
      renderTaskBoard(target, store, scrollState);
    });
  });

  target.querySelectorAll<HTMLButtonElement>('[data-action="prune"]').forEach((button) => {
    button.addEventListener('click', async () => {
      const cycleId = button.dataset.taskId ?? '';
      const state = store.getState();
      const item = state.tasks.find((entry) => entry.id === cycleId);
      if (!item) return;
      const otherTasks = [...new Map(state.tasks.filter((entry) => entry.taskId !== item.taskId).map((entry) => [entry.taskId, entry.title])).entries()]
        .map(([taskId, title]) => ({ taskId, title }));
      const input = await openPruneDialog({
        taskTitle: item.title,
        participants: state.participants,
        defaultActorId: item.responsibleUserId ?? state.participants[0]?.id,
        otherTasks,
      });
      if (!input) return;
      const scrollState = captureTaskBoardScrollState(target);
      await store.apply({ kind: 'prune', taskId: cycleId, input });
      renderTaskBoard(target, store, scrollState);
    });
  });
}

function setupTouchDrag(target: HTMLDivElement, store: FixtureTaskBoardStore, card: HTMLElement): void {
  card.style.touchAction = 'pan-y';
  const holdDelay = 400;
  const movementTolerance = 8;
  let startX = 0;
  let startY = 0;
  let holdTimer: number | undefined;
  let dragging = false;
  let dropTarget: HTMLElement | null = null;

  const clearHoldTimer = (): void => {
    if (holdTimer !== undefined) {
      window.clearTimeout(holdTimer);
      holdTimer = undefined;
    }
  };

  const cancelTouchDrag = (): void => {
    clearHoldTimer();
    card.classList.remove('task-card-dragging');
    clearTouchDropTargets(target);
    dragging = false;
    dropTarget = null;
  };

  card.addEventListener('pointerdown', (event) => {
    if (event.pointerType === 'mouse' || (event.target as HTMLElement).closest('button')) return;

    startX = event.clientX;
    startY = event.clientY;
    dragging = false;
    dropTarget = null;
    clearHoldTimer();

    holdTimer = window.setTimeout(() => {
      holdTimer = undefined;
      dragging = true;
      card.setPointerCapture(event.pointerId);
      card.classList.add('task-card-dragging');
      updateTouchDropTarget(target, event.clientX, event.clientY, (next) => {
        dropTarget = next;
      });
    }, holdDelay);
  });

  card.addEventListener('pointermove', (event) => {
    if (event.pointerType === 'mouse') return;

    const dx = event.clientX - startX;
    const dy = event.clientY - startY;

    if (!dragging) {
      if (Math.hypot(dx, dy) > movementTolerance) clearHoldTimer();
      return;
    }

    event.preventDefault();
    updateTouchDropTarget(target, event.clientX, event.clientY, (next) => {
      dropTarget = next;
    });
  });

  card.addEventListener('pointerup', (event) => {
    if (event.pointerType === 'mouse') return;

    clearHoldTimer();
    if (!dragging) return;

    event.preventDefault();
    if (card.hasPointerCapture(event.pointerId)) card.releasePointerCapture(event.pointerId);
    card.classList.remove('task-card-dragging');
    clearTouchDropTargets(target);

    const taskId = card.dataset.taskId;
    if (taskId && dropTarget) {
      applyTaskAssignment(target, store, taskId, dropTarget.dataset.dropTarget || undefined);
    }

    dragging = false;
    dropTarget = null;
  });

  card.addEventListener('pointercancel', () => {
    cancelTouchDrag();
  });
}

function updateTouchDropTarget(
  target: HTMLDivElement,
  x: number,
  y: number,
  onChange: (target: HTMLElement | null) => void,
): void {
  const element = document.elementFromPoint(x, y) as HTMLElement | null;
  const next = element?.closest<HTMLElement>('[data-drop-target]') ?? null;
  const current = target.querySelector<HTMLElement>('.task-column-drag-over');
  if (current === next) return;

  clearTouchDropTargets(target);
  next?.classList.add('task-column-drag-over');
  onChange(next);
}

function clearTouchDropTargets(target: HTMLDivElement): void {
  target.querySelectorAll('.task-column-drag-over').forEach((column) => column.classList.remove('task-column-drag-over'));
}

async function applyTaskAssignment(
  target: HTMLDivElement,
  store: FixtureTaskBoardStore,
  taskId: string,
  responsibleUserId: string | undefined,
): Promise<void> {
  const scrollState = captureTaskBoardScrollState(target);
  await store.apply({
    kind: 'assign',
    taskId,
    responsibleUserId,
  });
  renderTaskBoard(target, store, scrollState);
}

function captureTaskBoardScrollState(target: HTMLDivElement): TaskBoardScrollState {
  const board = target.querySelector<HTMLElement>('.task-board');
  return {
    board: board?.scrollTop ?? 0,
    lists: captureTaskListScrollPositions(target),
  };
}

function captureTaskListScrollPositions(target: HTMLDivElement): TaskListScrollPositions {
  const positions: TaskListScrollPositions = {};
  target.querySelectorAll<HTMLElement>('[data-task-list]').forEach((list) => {
    positions[list.dataset.taskList ?? ''] = list.scrollTop;
  });
  return positions;
}

function restoreTaskListScrollPositions(target: HTMLDivElement, positions: TaskListScrollPositions): void {
  target.querySelectorAll<HTMLElement>('[data-task-list]').forEach((list) => {
    const key = list.dataset.taskList ?? '';
    const position = positions[key];
    if (position !== undefined) list.scrollTop = position;
  });
}

function isTaskForToday(task: ReturnType<FixtureTaskBoardStore['getState']>['tasks'][number]): boolean {
  // Task Board data is real (FUNCTIONAL_FOUNDATION_PLAN.md Phase 2) and
  // already scoped to today's real window by ApiTaskBoardQuery; this only
  // needs to compare against the real current date, not the fixture date
  // still used for the ambient signature on this page.
  const today = new Date().toISOString().slice(0, 10);
  return !task.dueAt || task.dueAt.startsWith(today);
}

function renderParticipantColumn(
  participant: HouseholdParticipant,
  tasks: ReturnType<FixtureTaskBoardStore['getState']>['tasks'],
): string {
  const participantTasks = tasks.filter(
    (task) => task.assignment === 'individual' && task.responsibleUserId === participant.id,
  );

  return renderTaskColumn(participant.name, participant.id, participantTasks, participant);
}

function renderTaskColumn(
  heading: string,
  participantId: string | undefined,
  tasks: ReturnType<FixtureTaskBoardStore['getState']>['tasks'],
  participant?: HouseholdParticipant,
): string {
  const identity = participant
    ? `<button type="button" class="task-participant-identity" data-participant-id="${escapeHtml(participant.id)}" aria-label="Open ${escapeHtml(participant.name)}'s profile">
        <span class="task-participant-avatar" aria-hidden="true">${renderParticipantAvatar(participant)}</span>
        <span class="task-participant-name">${escapeHtml(participant.name)}</span>
      </button>`
    : `<h2>${escapeHtml(heading)}</h2>`;
  const orderedTasks = [...tasks].sort((left, right) => Number(left.status === 'completed') - Number(right.status === 'completed'));
  const scrollKey = participantId ?? 'household';

  return `
    <section class="task-column" data-drop-target="${participantId ?? ''}">
      <div class="task-column-heading">
        ${identity}
        <span>${tasks.filter((task) => task.status === 'pending').length}</span>
      </div>
      <div class="task-list" data-task-list="${escapeHtml(scrollKey)}">
        ${orderedTasks.map((task) => renderTaskCard(task)).join('')}
      </div>
    </section>
  `;
}

function renderParticipantAvatar(participant: HouseholdParticipant): string {
  if (participant.avatarUrl) {
    return `<img src="${escapeHtml(participant.avatarUrl)}" alt="">`;
  }

  return escapeHtml(participant.name.split(/\s+/).filter(Boolean).map((part) => part[0]).join('').slice(0, 2).toUpperCase());
}

function renderTaskCard(
  task: ReturnType<FixtureTaskBoardStore['getState']>['tasks'][number],
): string {
  const completed = task.status === 'completed';
  const reward = task.completionReward;
  const rewardLabel = reward
    ? `${reward.experience} XP · ${reward.credits} credits${reward.exceptional ? ' · Exceptional' : ''}`
    : '';
  const metadata = [
    task.dueAt ? formatTaskDue(task.dueAt) : '',
    ...(task.indicators ?? []),
  ].filter(Boolean);
  const completionLabel = task.completedAt ? `Done · ${formatTaskTime(task.completedAt)}` : '';

  return `
    <article class="task-card task-domain-${task.domain} ${completed ? 'task-card-completed' : ''}" draggable="true" data-task-id="${task.id}" tabindex="0" title="Drag to change responsibility">
      <div class="task-card-main">
        <div class="task-card-meta">
          ${completed && completionLabel ? `<time class="task-completion-meta" datetime="${escapeHtml(task.completedAt ?? '')}">${escapeHtml(completionLabel)}</time>` : metadata.length ? `<span class="task-context">${escapeHtml(metadata.join(' · '))}</span>` : ''}
        </div>
        <h3>${escapeHtml(task.title)}</h3>
      </div>
      <div class="task-card-footer">
        <span class="task-domain" aria-label="Domain">${escapeHtml(task.domain)}</span>
        <div class="task-card-actions">
          ${reward ? `<span class="task-reward ${reward.exceptional ? 'task-reward-exceptional' : ''}" aria-label="Reward earned">${escapeHtml(rewardLabel)}</span>` : ''}
          ${task.footholdEstablished ? `<span class="task-reward" aria-label="Foothold established">Foothold${task.footholdReward ? ` · +${task.footholdReward.experience} XP` : ''}</span>` : ''}
          <button type="button" class="task-edit" data-action="edit" data-task-def="${task.taskId}">Edit</button>
          ${!completed && task.task.supports_foothold && !task.footholdEstablished ? `<button type="button" class="task-edit" data-action="foothold" data-task-id="${task.id}">Start</button>` : ''}
          ${!completed ? `<button type="button" class="task-edit" data-action="prune" data-task-id="${task.id}">Not needed</button>` : ''}
          <button type="button" class="task-complete" data-action="complete" data-task-id="${task.id}" aria-label="${completed ? 'Undo completion (removes the reward it granted)' : 'Mark task as done'}">
            ${completed ? 'Undo' : 'Complete'}
          </button>
        </div>
      </div>
    </article>
  `;
}

function formatTaskDue(value: string): string {
  const date = new Date(value);
  const sameDay = value.startsWith(new Date().toISOString().slice(0, 10));
  const time = new Intl.DateTimeFormat('en-CA', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(date);

  if (sameDay) return time;

  return `${new Intl.DateTimeFormat('en-CA', { month: 'short', day: 'numeric' }).format(date)} · ${time}`;
}

function formatTaskTime(value: string): string {
  return new Intl.DateTimeFormat('en-CA', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(new Date(value));
}

function renderAmbientContext(value: AmbientContext): string {
  if (value.kind === 'transient') {
    return `<aside class="ambient-context ambient-context-transient" aria-live="polite"><span class="ambient-message">${escapeHtml(value.message)}</span></aside>`;
  }

  return `<aside class="ambient-context" aria-label="Current household context"><span class="ambient-message">${escapeHtml(value.date)} · ${escapeHtml(value.time)} · ${escapeHtml(value.weather)}</span></aside>`;
}

function renderOccurrences(occurrences: TemporalOccurrence[], horizonNow: string): string {
  // Eligibility (relevance/significance) decides the input set; horizon.ts's
  // own candidate selection then applies the temporal-window/departure-grace
  // admission gate and composition occupancy cap (EVENT_HORIZON.md §10/§16).
  const eligibleEvents = occurrences.filter(isHorizonEligible).map(toHorizonEvent);
  const candidates = selectHorizonCandidates(eligibleEvents, horizonNow);
  return candidates.map((event) => renderOccurrence(event, horizonNow)).join('');
}

function toHorizonEvent(occurrence: TemporalOccurrence): HorizonEvent {
  return {
    id: occurrence.occurrence_id,
    title: occurrence.title,
    timeLabel: formatTime(occurrence.starts_at),
    occurrenceStart: occurrence.starts_at ?? `${occurrence.local_start_date}T00:00:00${offsetForTimezone(occurrence.timezone)}`,
  };
}

function renderOccurrence(event: HorizonEvent, horizonNow: string): string {
  const position = horizonPosition(event, horizonNow);
  const visual = horizonVisual(event, horizonNow);
  const style = [
    `left:${(position.x * 100).toFixed(3)}%`, `top:${(position.y * 100).toFixed(3)}%`,
    `--opacity:${visual.opacity.toFixed(3)}`, `--font-size:${Math.max(10, Math.min(25, 10 + visual.size * 10)).toFixed(2)}px`,
    `--scale:${visual.scale.toFixed(3)}`, `--blur:${visual.blur.toFixed(2)}px`, `--tracking:${visual.tracking}`,
    `--weight:${visual.weight}`, `--time-opacity:${visual.timeOpacity.toFixed(3)}`, `--time-scale:${visual.timeScale.toFixed(3)}`,
    `--time-rise:${visual.timeRise}`,
  ].join(';');

  return `<article class="horizon-event" style="${style}"><span class="horizon-event-title">${escapeHtml(event.title)}</span><span class="horizon-event-time">${escapeHtml(event.timeLabel)}</span></article>`;
}

function formatTime(value?: string): string {
  if (!value) return 'All day';
  return new Intl.DateTimeFormat('en-CA', { hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(value));
}

function offsetForTimezone(timezone: string): string {
  if (timezone === 'America/Toronto') return '-04:00';
  return 'Z';
}

function escapeHtml(value: string): string {
  return value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;').replaceAll("'", '&#039;');
}
